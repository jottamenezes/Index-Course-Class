# Pure CSS geometric pattern

A Pen created on CodePen.io. Original URL: [https://codepen.io/thebabydino/pen/wvXpMrX](https://codepen.io/thebabydino/pen/wvXpMrX).

